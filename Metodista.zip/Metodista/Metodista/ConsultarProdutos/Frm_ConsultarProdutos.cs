﻿using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.ConsultarProdutos
{
    public partial class Frm_ConsultarProdutos : Form
    {
        // declarando os atributos da classe
        private ConexaoBancoDados db = new ConexaoBancoDados();
        private MySqlDataReader reader;
        private string sql;

        // construtor da classe
        public Frm_ConsultarProdutos()
        {
            InitializeComponent();
        }

        // metodos da classe
        private void lblSair_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_ConsultarProdutos.ActiveForm.Close();
        }

        private void Frm_ConsultarProdutos_FormClosing(object sender, FormClosingEventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
        }

        private void Frm_ConsultarProdutos_Load(object sender, EventArgs e)
        {
            try
            {

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select * from categoria;";

                // buscar os dados
                reader = db.SelectDados(sql);

                if (reader.HasRows) // true = tem dados ou false = nao tem dados
                {
                    // limpar o combobox
                    cbCategoria.Items.Clear();

                    // lendo as informaçoes do banco de dados
                    while (reader.Read())
                    {
                        cbCategoria.Items.Add(reader.GetString(0) + " - " + reader.GetString(1));
                    }
                    cbCategoria.Items.Add("");
                   
                }
              
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }
        }

        private void cbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            string codCategoria = null;

            try
            {
                // pegar do combobox cbCategoria o codigo da categoria
                codCategoria = cbCategoria.Text.Split('-')[0].Trim();

                if (String.IsNullOrEmpty(codCategoria)) { return; }

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select * from produtos where codcate = '" + codCategoria + "';";

                // buscar os dados
                reader = db.SelectDados(sql);

                // limpar o combobox
                cbProduto.Items.Clear();

                if (reader.HasRows) // true = tem dados ou false = nao tem dados
                {

                    // lendo as informaçoes do banco de dados
                    while (reader.Read())
                    {
                        cbProduto.Items.Add(reader.GetString(0) + " - " + reader.GetString(2));
                    }

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }

        }

        private void cbProduto_SelectedIndexChanged(object sender, EventArgs e)
        {
            string codProd = null;
            string[] dados = new string[4];

            try
            {
                // pegar do combobox cbCategoria o codigo da categoria
                codProd = cbProduto.Text.Split('-')[0].Trim();

                if (String.IsNullOrEmpty(codProd)) { return; }

                // conectando o banco de dados
                db.ConectarBancoDados();
              
                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select * from precoproduto where codprod = '" + codProd + "';";

                // buscar os dados
                reader = db.SelectDados(sql);

                // limpar o DataGridView
                dgvDados.Rows.Clear();

                // limpando o vetor
                Array.Clear(dados, 0, dados.Length);

                if (reader.HasRows) // true = tem dados ou false = nao tem dados
                {

                    // lendo as informaçoes do banco de dados
                    while (reader.Read())
                    {
                        dados[0] = reader.GetString(0);
                        dados[1] = reader.GetString(1);
                        dados[2] = reader.GetString(2);
                        dados[3] = reader.GetString(3);

                        // inserindo as linhas no DataGridView
                        dgvDados.Rows.Add(dados);
                    }

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
