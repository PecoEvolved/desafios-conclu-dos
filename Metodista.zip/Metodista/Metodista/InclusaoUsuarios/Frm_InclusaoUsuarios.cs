﻿using Metodista.AlterarProdutos;
using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.InclusaoUsuarios
{
    public partial class Frm_InclusaoUsuarios : Form
    {
        ConexaoBancoDados db = new ConexaoBancoDados(); 
        MySqlDataReader reader;
        string sql;

        public Frm_InclusaoUsuarios()
        {
            InitializeComponent();
        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_InclusaoUsuarios.ActiveForm.Close();
        }

        private void lblCancela_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_InclusaoUsuarios.ActiveForm.Close();
        }

        private void lblConfirma_Click(object sender, EventArgs e)
        {

            try
            {

                // verificar se o campo usuario foi preenchido
                if (String.IsNullOrEmpty(tUsu.Text)) 
                {
                    MessageBox.Show("Campo obrigatório!!!");
                    tUsu.Focus();
                    return;
                }

                if (String.IsNullOrEmpty(tSen.Text))
                {
                    MessageBox.Show("Campo obrigatório!!!");
                    tSen.Focus();
                    return;
                }

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select usuario from tab_usuarios where usuario = '" + tUsu.Text + "';";

                // buscar os dados
                reader = db.SelectDados(sql);

                if (reader.HasRows) // true false
                {
                    MessageBox.Show("Usuário já cadastrado!!!");
                    if (db.conn != null) { db.conn.Close(); db.conn = null; }
                    if (reader != null) { reader.Close(); reader = null; }
                    return;
                } else
                {
                    // fechando o objeto reader
                    if (reader != null) { reader.Close(); reader = null; }

                    // preparando a query (busca/select)
                    sql = "insert into tab_usuarios (usuario, senha) values ('" + tUsu.Text + "', '" + tSen.Text + "');";

                    if (db.InsertDados(sql))
                    {
                        MessageBox.Show("Usuário incluído com sucesso!!!");

                        db.CommitBanco();

                        if (db.conn != null) { db.conn.Close(); db.conn = null; }
                        if (reader != null) { reader.Close(); reader = null; }
                        return;
                    }
                                     
                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }

        }
    }
}
