﻿using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.IncluirProdutos
{
    public partial class Frm_InclusaoProdutos : Form
    {
        ConexaoBancoDados db = new ConexaoBancoDados();
        MySqlDataReader reader;
        string sql;

        public Frm_InclusaoProdutos()
        {
            InitializeComponent();
        }

        private void Frm_InclusaoProdutos_Load(object sender, EventArgs e)
        {

            try
            {

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select * from categoria order by codigo;";

                // buscar os dados
                reader = db.SelectDados(sql);

                if (reader.HasRows) // true false
                {
                    // limpa 
                    lbCategoria.Items.Clear();

                    while (reader.Read())
                    {
                        lbCategoria.Items.Add(reader.GetString(0) + " - " + reader.GetString(1));
                    }

                }
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }


        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            if (reader != null) { reader.Close(); reader = null; }
            Frm_InclusaoProdutos.ActiveForm.Close();
        }

        private void lbCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                string categoria = lbCategoria.Items[lbCategoria.SelectedIndex].ToString();
                categoria = categoria.Trim().Split('-')[0].Trim();

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select codcate, nomeproduto from produtos where codcate = '" + categoria + "';";

                // buscar os dados
                reader = db.SelectDados(sql);

                if (reader.HasRows) // true false
                {
                    // limpa 
                    lbProdutos.Items.Clear();

                    while (reader.Read())
                    {
                        lbProdutos.Items.Add(reader.GetString(0) + " - " + reader.GetString(1));
                    }

                }
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }

        }

        private void lblNewProdutos_Click(object sender, EventArgs e)
        {
            try
            {

                // verificar se o campo usuario foi preenchido
                if (String.IsNullOrEmpty(tNewProdutos.Text))
                {
                    MessageBox.Show("Campo obrigatório!!!");
                    tNewProdutos.Focus();
                    return;
                }

                // conectando o banco de dados
                db.ConectarBancoDados();

                // fechando o objeto reader
                if (reader != null) { reader.Close(); reader = null; }

                // preparando a query (busca/select)
                sql = "select nomeproduto from produtos where nomeproduto = '" + tNewProdutos.Text.Split('-')[1].Trim() + "';";

                // buscar os dados
                reader = db.SelectDados(sql);

                if (reader.HasRows) // true false
                {
                    MessageBox.Show("Produto já cadastrado!!!");
                    if (db.conn != null) { db.conn.Close(); db.conn = null; }
                    if (reader != null) { reader.Close(); reader = null; }
                    return;
                }
                else
                {
                    // fechando o objeto reader
                    if (reader != null) { reader.Close(); reader = null; }

                    // preparando a query (busca/select)
                    sql = "insert into produtos (codcate, nomeproduto) values ('" + tNewProdutos.Text.Split('-')[0].Trim() + "', '" + tNewProdutos.Text.Split('-')[1].Trim() + "');";

                    if (db.InsertDados(sql))
                    {
                        MessageBox.Show("Produto incluído com sucesso!!!");

                        db.CommitBanco();

                        if (db.conn != null) { db.conn.Close(); db.conn = null; }
                        if (reader != null) { reader.Close(); reader = null; }
                        return;
                    }

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                if (reader != null) { reader.Close(); reader = null; }
            }

        }
    }
}
