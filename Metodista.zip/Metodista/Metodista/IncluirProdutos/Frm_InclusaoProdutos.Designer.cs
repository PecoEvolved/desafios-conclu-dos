﻿namespace Metodista.IncluirProdutos
{
    partial class Frm_InclusaoProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbCategoria = new System.Windows.Forms.ListBox();
            this.tNewCategoria = new System.Windows.Forms.TextBox();
            this.lblNewCategoria = new System.Windows.Forms.Label();
            this.lblSair = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblNewProdutos = new System.Windows.Forms.Label();
            this.tNewProdutos = new System.Windows.Forms.TextBox();
            this.lbProdutos = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(107, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(655, 73);
            this.label1.TabIndex = 26;
            this.label1.Text = "Inclusão de novos produtos";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Categorias";
            // 
            // lbCategoria
            // 
            this.lbCategoria.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCategoria.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbCategoria.ForeColor = System.Drawing.Color.Navy;
            this.lbCategoria.FormattingEnabled = true;
            this.lbCategoria.Location = new System.Drawing.Point(16, 133);
            this.lbCategoria.Name = "lbCategoria";
            this.lbCategoria.Size = new System.Drawing.Size(243, 93);
            this.lbCategoria.TabIndex = 29;
            this.lbCategoria.SelectedIndexChanged += new System.EventHandler(this.lbCategoria_SelectedIndexChanged);
            // 
            // tNewCategoria
            // 
            this.tNewCategoria.ForeColor = System.Drawing.Color.Navy;
            this.tNewCategoria.Location = new System.Drawing.Point(16, 240);
            this.tNewCategoria.Name = "tNewCategoria";
            this.tNewCategoria.Size = new System.Drawing.Size(187, 20);
            this.tNewCategoria.TabIndex = 30;
            // 
            // lblNewCategoria
            // 
            this.lblNewCategoria.Image = global::Metodista.Properties.Resources.novo;
            this.lblNewCategoria.Location = new System.Drawing.Point(209, 233);
            this.lblNewCategoria.Name = "lblNewCategoria";
            this.lblNewCategoria.Size = new System.Drawing.Size(50, 33);
            this.lblNewCategoria.TabIndex = 31;
            this.lblNewCategoria.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSair
            // 
            this.lblSair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSair.BackColor = System.Drawing.Color.Transparent;
            this.lblSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSair.Image = global::Metodista.Properties.Resources.sair;
            this.lblSair.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblSair.Location = new System.Drawing.Point(768, 9);
            this.lblSair.Name = "lblSair";
            this.lblSair.Size = new System.Drawing.Size(44, 73);
            this.lblSair.TabIndex = 27;
            this.lblSair.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSair.Click += new System.EventHandler(this.lblSair_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Metodista.Properties.Resources.metodista;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(89, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // lblNewProdutos
            // 
            this.lblNewProdutos.Image = global::Metodista.Properties.Resources.novo;
            this.lblNewProdutos.Location = new System.Drawing.Point(712, 233);
            this.lblNewProdutos.Name = "lblNewProdutos";
            this.lblNewProdutos.Size = new System.Drawing.Size(50, 33);
            this.lblNewProdutos.TabIndex = 35;
            this.lblNewProdutos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNewProdutos.Click += new System.EventHandler(this.lblNewProdutos_Click);
            // 
            // tNewProdutos
            // 
            this.tNewProdutos.ForeColor = System.Drawing.Color.Navy;
            this.tNewProdutos.Location = new System.Drawing.Point(380, 240);
            this.tNewProdutos.Name = "tNewProdutos";
            this.tNewProdutos.Size = new System.Drawing.Size(326, 20);
            this.tNewProdutos.TabIndex = 34;
            // 
            // lbProdutos
            // 
            this.lbProdutos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbProdutos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbProdutos.ForeColor = System.Drawing.Color.Navy;
            this.lbProdutos.FormattingEnabled = true;
            this.lbProdutos.Location = new System.Drawing.Point(380, 133);
            this.lbProdutos.Name = "lbProdutos";
            this.lbProdutos.Size = new System.Drawing.Size(382, 93);
            this.lbProdutos.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(377, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "Produtos";
            // 
            // Frm_InclusaoProdutos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(824, 503);
            this.Controls.Add(this.lblNewProdutos);
            this.Controls.Add(this.tNewProdutos);
            this.Controls.Add(this.lbProdutos);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblNewCategoria);
            this.Controls.Add(this.tNewCategoria);
            this.Controls.Add(this.lbCategoria);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSair);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ForeColor = System.Drawing.Color.Navy;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm_InclusaoProdutos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inclusão de novos produtos";
            this.Load += new System.EventHandler(this.Frm_InclusaoProdutos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSair;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lbCategoria;
        private System.Windows.Forms.TextBox tNewCategoria;
        private System.Windows.Forms.Label lblNewCategoria;
        private System.Windows.Forms.Label lblNewProdutos;
        private System.Windows.Forms.TextBox tNewProdutos;
        private System.Windows.Forms.ListBox lbProdutos;
        private System.Windows.Forms.Label label4;
    }
}